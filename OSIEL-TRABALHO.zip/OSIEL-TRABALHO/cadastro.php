

<!DOCTYPE html>
<html>
<head>  
  <title>Cadastro</title>
 <style type="text/css">
   
    body{
      width: 100%;
      background-color: black;
    }

    #POST{
      margin-top: 5px;
      height: 500px;
      width: 700px;
      padding: 15px;
      background-color: #66f9ff;
      border-radius: 10px;
      line-height:90px;
      box-shadow: 0 0 15px #66ffff;
    }
    #circle{
      height: 100%;
      width: 75%;
      border-radius: 400px;
      background-color: none;
      padding-bottom: 30px;
      border : 4px solid #00cccc;
      top: 50px;
    }
    #in{
      
      width: 90%;
      height: 40px;
      border-radius: 10px;
      padding: 20px;      
      border : 4px solid #00cccc;
      background-color: #C0C2ED;
      color: rad;
    }
    #in:focus{
      border:6px solid #00cccc;
    }
    #inBtn{
      margin-top: 2px;
      width: 90%;
      height: 50px;
      border-radius: 10px;
      line-height:10px;
      border : 4px solid #00cccc;
      background-color: #333333;
      color:black;
      cursor: pointer;
    }
    #copy{
      color: #00cccc;
      text-align: center;
      font-style: italic;
    }
    footer{
      position:fixed;       
      bottom:0px;
      left:0px;
      right:0px;
      margin-bottom:0px;
    }
    hr{
      color: #00cccc;
    }
 </style>
  

</head>
<body background="https://farm4.staticflickr.com/3940/32677535044_606bd74352_c.jpg" style="background-repeat:no-repeat;background-size:cover;" >
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js">

   <script src="jQuery/jquery-3.1.1.min.js" type="text/javascript">
   <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
      $("#circle").hide();
      $("#box").animate({height:"280px"},"slow");
      $("#box").animate({width:"450px"},"slow");
      $("#circle").fadeIn(1000);

    });
    function blinker(){
      $('#blinking').fadeOut("slow");
      $('#blinking').fadeIn("slow");
    }
    setInterval(blinker, 1000);

  </script>
  <br>
  <hr>
  <h1 align="center" style="color:#00cccc;">Preencha as informações abaixo</h1>
  <hr>
  <br>
  <form>
    <center>
      <div id="circle">
        <h1 id="blinking" style="color: #00cccc;">Bem vindo</h1>
        <div id="POST">
          <form method="POST">
            <input type="text" name="nome" id="in" placeholder="nome" required><br>
            <input type="text" name="fone" placeholder="fone" id="in" required><br>
            <input type="text" name="cidade" placeholder="cidade" id="in"required><br>
            <input type="text" name="altura" placeholder="altura" id="in"required><br>
            <input type="text" name="idade" placeholder="idade" id="in"required>
            <input type="submit" name="acao" value="Enviar" id="inBtn" style="color:white;">
         </form> 
        </div>
      </div>
    </center>

    
  </form>

  <br><br><br><br>
  <!-- <hr>-->
    <p id="footer">Misfar ©</p>
  <hr> 
  <footer>
    <hr>
      <p id="copy">Ayaal Shahim ©</p>
    <hr>
  </footer>  
</body>
</html>