
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Tabelas</title>
	<style type="text/css">
		
table{

  border: 3px solid;
  text-align: center;
   padding-top: 12px;
    padding: 8px;
 
  
}
		th {
  background-color: #04AA6D;
  color: white;
  border: 4;
  padding: 28px;

  
}

</style>
</head>
<body>
<?php  
 
 $pdo = new PDO('mysql:host=localhost;dbname=trabalho','root','');

 $sql = $pdo->prepare("SELECT * FROM `formul`");

  echo"<center><table border='5'>
     <tr>
        <th>Nome</th>
        <th>fone</th>
        <th>cidade</th>
        <th>altura</th>
        <th>idade</th>
     </tr>
     </center>";

    $sql->execute();   
     
     $table = $sql->fetchall();
         foreach ($table as $key => $value) {
          echo "<tr>";
           echo "<th>".$value["nome"]."</th>";           
           
           echo "<td>".$value['fone']."</td>";
           
           echo "<th>".$value['cidade']."</th>";
          
           echo"<td>".$value['altura']. "</td>";
           
           echo "<th>".$value['idade']. "</th>";           
           echo "</tr>";
         }
    
?>
</body>
</html>

