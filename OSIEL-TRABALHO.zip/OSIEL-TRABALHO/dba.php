<?php
include 'cadastro.php';
 $pdo = new PDO('mysql:host=localhost;dbname=trabalho','root','');  
 
  if(isset($_POST['acao'])){
    $nome = $_POST['nome'];
    $fone = $_POST['fone'];
    $cidade = $_POST['cidade'];
    $altura = $_POST['altura'];
    $idade = $_POST['idade'];

    $sql = $pdo->prepare("INSERT INTO `formul` VALUES (null,?,?,?,?,?)");
    $sql->execute(array($nome,$fone,$cidade,$altura,$idade));
    
    echo 'inserido com sucesso!';

  }
  else
  {
    echo 'Erro tente novamente';
  }

   
 
?>